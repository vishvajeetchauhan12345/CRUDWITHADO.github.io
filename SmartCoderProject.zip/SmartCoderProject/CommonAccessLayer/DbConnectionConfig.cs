﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonAccessLayer
{
    public class DbConnectionConfig
    {
        public static string ConnectionString { get; set; }
    }
}
