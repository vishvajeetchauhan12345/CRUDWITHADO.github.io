﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Data.SqlClient;
using Microsoft.Data;
using CommonAccessLayer;

namespace DataAccessLayer
{
    public class DbConnect
    {
        public SqlConnection connection;
        public DbConnect() 
        {
            connection = new SqlConnection(DbConnectionConfig.ConnectionString);
        }
    }
}
