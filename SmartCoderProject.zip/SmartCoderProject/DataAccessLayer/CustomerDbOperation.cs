﻿using CommonAccessLayer.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace DataAccessLayer
{
    public class CustomerDbOperation
    {
        private DbConnect dbConnect;
        public CustomerDbOperation() 
        {
            dbConnect = new DbConnect();
        }
        public List<Customer> GetCustomers()
        {
            SqlCommand command = new SqlCommand("SP_MASTERTABLE",dbConnect.connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@action","SELECT");
           
            if (dbConnect.connection.State == ConnectionState.Closed)
                dbConnect.connection.Open();
            
            SqlDataReader dr = command.ExecuteReader();
            List<Customer> customers = new List<Customer>();
            while (dr.Read())
            {
                Customer obj = new Customer();
                obj.Id=(int)dr["Id"];
                obj.FirstName = dr["FirstName"].ToString();
                obj.LastName = dr["LastName"].ToString();
                obj.DOB = dr["DOB"].ToString();
                obj.Gender = dr["Gender"].ToString();
                obj.Contact = dr["Contact"].ToString();
                obj.Email = dr["Email"].ToString();
                obj.Address = dr["Address"].ToString();
                customers.Add(obj);
            }
            dbConnect.connection.Close();
            return customers;
        }
        public Customer GetUserById(int id)
        {
            SqlCommand command = new SqlCommand("SP_MASTERTABLE",dbConnect.connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@action","SELECT_SINGLE");
            command.Parameters.AddWithValue("@Id",id);
            if (dbConnect.connection.State == ConnectionState.Closed)
                dbConnect.connection.Open();
            SqlDataReader dr = command.ExecuteReader();
            Customer obj = new Customer();
            
            while (dr.Read())
            { 
            obj.Id = (int)dr["Id"];
            obj.FirstName = dr["FirstName"].ToString();
            obj.LastName = dr["LastName"].ToString();
            obj.DOB = dr["DOB"].ToString();
            obj.Gender = dr["Gender"].ToString();
            obj.Contact = dr["Contact"].ToString();
            obj.Email = dr["Email"].ToString();
            obj.Address = dr["Address"].ToString();
            }
            dbConnect.connection.Close();
            return obj;
        }
        public void Create(Customer model)
        {
            SqlCommand command = new SqlCommand("SP_MASTERTABLE", dbConnect.connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@action", "CREATE");
            
            command.Parameters.AddWithValue("@FirstName",model.FirstName);
            command.Parameters.AddWithValue("@LastName", model.LastName);
            command.Parameters.AddWithValue("@DOB", model.DOB);
            command.Parameters.AddWithValue("@Gender", model.Gender);
            command.Parameters.AddWithValue("@Contact", model.Contact);
            command.Parameters.AddWithValue("@Email", model.Email);
            command.Parameters.AddWithValue("@Address", model.Address);
           
            if (dbConnect.connection.State == ConnectionState.Closed)
                dbConnect.connection.Open();
            command.ExecuteNonQuery();
            dbConnect.connection.Close();
      
        }
        public void Update(Customer model) 
        {
            SqlCommand command = new SqlCommand("SP_MASTERTABLE",dbConnect.connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@action","UPDATE");
            command.Parameters.AddWithValue("@Id", model.Id);
            command.Parameters.AddWithValue("@FirstName", model.FirstName);
            command.Parameters.AddWithValue("@LastName", model.LastName);
            command.Parameters.AddWithValue("@DOB", model.DOB);
            command.Parameters.AddWithValue("@Gender", model.Gender);
            command.Parameters.AddWithValue("@Contact", model.Contact);
            command.Parameters.AddWithValue("@Email", model.Email);
            command.Parameters.AddWithValue("@Address", model.Address);
            
            if (dbConnect.connection.State == ConnectionState.Closed)
                dbConnect.connection.Open();
            command.ExecuteNonQuery();
            dbConnect.connection.Close();
          
        }
        public void Delete(int id)
        {
            SqlCommand command = new SqlCommand("SP_MASTERTABLE",dbConnect.connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@action","DELETE");
            command.Parameters.AddWithValue("@Id", id);
            
            if (dbConnect.connection.State == ConnectionState.Closed)
                dbConnect.connection.Open();
            command.ExecuteNonQuery();
            
            dbConnect.connection.Close();
         
        }
    }
}
