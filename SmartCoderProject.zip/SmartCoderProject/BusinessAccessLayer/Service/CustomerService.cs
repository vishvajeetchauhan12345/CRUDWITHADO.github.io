﻿using BusinessAccessLayer.Contract;
using CommonAccessLayer.Models;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessAccessLayer.Service
{
    public class CustomerService : ICustomer
    {
        private CustomerDbOperation dboperation;
        public CustomerService() 
        {
            dboperation = new CustomerDbOperation();
        }

        public void CreateCustomer(Customer model)
        {
            dboperation.Create(model);
         
        }

        public List<Customer> Customers()
        {
            return dboperation.GetCustomers();
        }

        public void DeleteCustomer(int id)
        {
            dboperation.Delete(id);
        }

        public Customer GetCustomer(int id)
        {
            var user = dboperation.GetUserById(id);
            if (user != null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public void UpdateCustomer(Customer model)
        {
            dboperation.Update(model);
            
        }
    }
}
