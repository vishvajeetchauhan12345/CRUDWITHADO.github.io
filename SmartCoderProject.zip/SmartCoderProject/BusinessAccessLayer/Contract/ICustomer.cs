﻿using CommonAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessAccessLayer.Contract
{
    public interface ICustomer
    {
        List<Customer> Customers();
        void CreateCustomer(Customer model);
        void UpdateCustomer(Customer model);
        void DeleteCustomer(int id);
        Customer GetCustomer(int id);
    }
}
