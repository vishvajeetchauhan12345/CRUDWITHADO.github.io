﻿using BusinessAccessLayer.Contract;
using CommonAccessLayer.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartCoderProject.Controllers
{
    public class CustomerController : Controller
    {

        private ICustomer custmerService;
        public CustomerController(ICustomer service)
        {
            custmerService = service;
        }
        public IActionResult Index()
        {
            var list = custmerService.Customers();
            return View(list);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Customer model)
        {
           
            custmerService.CreateCustomer(model);
            return RedirectToAction("Index", "Customer");


        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
                custmerService.DeleteCustomer(id);
           
                ModelState.AddModelError(string.Empty, "Deleted User Successfully");
                return RedirectToAction("Index", "Customer");
           
            
        }
        [HttpGet]
        public IActionResult UPDATE(int id)
        {
            var user = custmerService.GetCustomer(id);
            return View(user);
        }
        [HttpPost]
        public IActionResult UPDATE(Customer model)
        {
            custmerService.UpdateCustomer(model);
            return RedirectToAction("Index", "Customer");
        }
    }
}
